package com.viewnext.models;

import java.util.ArrayList;
import java.util.List;

@FunctionalInterface
public interface Colecciones<T> {
	
	void abstracto();
	
	default List<T> lista(){
		return new ArrayList<T>();
	}
	
	default void vacio() {
		
	}
	
	static char letra() {
		return 'b';
	}

}
