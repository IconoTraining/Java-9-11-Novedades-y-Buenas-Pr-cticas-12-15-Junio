package com.viewnext.models;

@FunctionalInterface
public interface ITextos {
	
	private String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	private String minusculas(String texto) {
		return texto.toLowerCase();
	}
	
	private int longitud(String texto) {
		return texto.length();
	}
	
	default String mostrar(String texto) {
		return "Mayusculas: " + mayusculas(texto) +
				" Minusculas: " + minusculas(texto) +
				" Longitud: " + longitud(texto);
	}
	
	default void prueba() {
		System.out.println("Hola");
	}
	
	static int numero() {
		return 7;
	}
	
	static char letra() {
		return 'b';
	}
	
	void solicitarTexto();
	
	// Para que sea considerada una interface funcional
	// debe tener SOLO un metodo abstracto
	// void solicitarTexto2();

}
