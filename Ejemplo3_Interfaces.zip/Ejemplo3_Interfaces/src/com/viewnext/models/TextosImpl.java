package com.viewnext.models;

import java.util.Scanner;

public class TextosImpl implements ITextos{

	@Override
	public void solicitarTexto() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce texto: ");
		String texto = sc.nextLine();
		System.out.println(mostrar(texto));	
		sc.close();
	}

}
