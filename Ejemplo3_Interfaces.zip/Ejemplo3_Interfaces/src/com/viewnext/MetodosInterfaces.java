package com.viewnext;

import com.viewnext.models.Colecciones;

public class MetodosInterfaces {

	public static void main(String[] args) {
		// Invocar al metodo estatico de la interface
		char letra = Colecciones.letra();
		
		// Implementar el metodo abstracto
		Colecciones<Integer> numeros = () -> {
			int i = (3+6);
		};
		
		// Invocar al metodo default 
		System.out.println(numeros.lista());
		System.out.println(numeros.getClass());
	}

}
