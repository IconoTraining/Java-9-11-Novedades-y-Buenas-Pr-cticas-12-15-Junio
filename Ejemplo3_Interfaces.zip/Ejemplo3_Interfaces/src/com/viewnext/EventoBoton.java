package com.viewnext;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class EventoBoton {
	
	private JFrame frame = new JFrame("Ejemplo boton");
	private JButton boton = new JButton("Pulsame");
	
	private void mostrarVentana() {
		// Sin Lambda
		//boton.addActionListener(new BotonListener());
		
		
		// Con Lambda
		boton.addActionListener(
			(ActionEvent e) -> {
				System.out.println("El boton se ha pulsado " + e);
			}
		);
		
		frame.add(boton, BorderLayout.CENTER);
		frame.setSize(300, 200);
		frame.setVisible(true);
	}

	public static void main(String[] args) {		
		new EventoBoton().mostrarVentana();
	}

}

//class BotonListener implements ActionListener{
//
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		System.out.println("El boton se ha pulsado " + e);
//		
//	}
//	
//}
