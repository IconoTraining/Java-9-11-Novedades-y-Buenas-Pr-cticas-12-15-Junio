package com.viewnext;

import com.viewnext.models.TextosImpl;

public class AppMain {

	public static void main(String[] args) {
		
		new TextosImpl().solicitarTexto();
		

	}

}
