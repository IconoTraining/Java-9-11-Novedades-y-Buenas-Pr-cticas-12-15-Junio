module Ejemplo3_Interfaces {
	requires java.desktop;
}