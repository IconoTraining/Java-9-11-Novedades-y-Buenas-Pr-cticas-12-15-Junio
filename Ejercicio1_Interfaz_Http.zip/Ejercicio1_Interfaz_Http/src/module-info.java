module servicio {
	
	requires java.net.http;
	exports com.viewnext.interfaz;
}