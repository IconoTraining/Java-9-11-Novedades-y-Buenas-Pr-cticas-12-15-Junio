package com.viewnext.interfaz;

import java.net.http.HttpResponse;

public interface ItfzHttp {
	
	HttpResponse<String> solicitar(String url) throws Exception;

}
