package com.viewnext;

import java.lang.reflect.Method;

public class AppMain {
	
	
	public static void main(String[] args) throws Exception {
		EjemploUI ui = new EjemploUI();
		
		// A través de reflection intento acceder a un metodo privado
		// java.lang.IllegalAccessException
		//Method method = ui.getClass().getDeclaredMethod("metodoPrivado");
		//method.invoke(ui);
		
		// En Java 11 se introduce esta mejora
		Method method = ui.getClass().getNestHost().getDeclaredMethod("metodoPrivado");
		method.setAccessible(true);
		method.invoke(ui);
		
		ui.launchFrame();
	}

}











