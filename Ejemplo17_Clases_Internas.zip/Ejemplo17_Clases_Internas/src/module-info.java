module Ejemplo17_Clases_Internas {
	requires java.desktop;
}