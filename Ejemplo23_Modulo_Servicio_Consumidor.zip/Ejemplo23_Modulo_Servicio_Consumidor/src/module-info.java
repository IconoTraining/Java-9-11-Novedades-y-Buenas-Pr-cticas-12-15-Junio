module consumidor {
	
	requires service;
	uses com.viewnext.interfaz.ItfzSaludo;
	
}