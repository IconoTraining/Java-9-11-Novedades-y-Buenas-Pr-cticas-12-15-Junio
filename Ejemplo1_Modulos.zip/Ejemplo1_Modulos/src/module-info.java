module com.viewnext.primermodulo {
	exports com.viewnext.models;
}