package com.viewnext.persistence;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.viewnext.models.Producto;

public class ProductosDAO {
	
	// crear una lista estatica con 5 productos
	private static List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Scanner", 140.50),
			new Producto(3, "Teclado", 35),
			new Producto(4, "Raton", 22),
			new Producto(5, "Impresora", 87.30));
	
	
	// crear un metodo que devuelva todos los productos
	public List<Producto> consultarTodos(){
		return lista;
	}
	
	
	// crear otro metodo que busque un producto por su id y lo retorne
	public Optional<Producto> buscarProducto(int id) {
		
		for (Producto producto : lista) {
			if (id == producto.getId()) {
				return Optional.of(producto);
			}
		}
		
		// Si no lo encuentro devuelvo el producto vacio
		return Optional.empty();
	}
	

}
