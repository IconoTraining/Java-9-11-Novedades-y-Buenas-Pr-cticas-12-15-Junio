package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {
	
	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		//dao.consultarTodos().stream().forEach(System.out::println);
		
		// Primera forma
//		Producto encontrado = dao.buscarProducto(22222).orElse(new Producto());
//		System.out.println(encontrado);
		
		
		// Segunda forma
		Optional<Producto> opProducto = dao.buscarProducto(22222);
		if (opProducto.isPresent()) {
			System.out.println(opProducto.get());
		} else {
			System.out.println("Producto no encontrado");
		}
	}

}
