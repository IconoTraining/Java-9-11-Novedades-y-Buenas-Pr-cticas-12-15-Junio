module proveedor {
	
	requires java.net.http;
	requires servicio;
	provides com.viewnext.interfaz.ItfzHttp with com.viewnext.business.HttpImpl;
}