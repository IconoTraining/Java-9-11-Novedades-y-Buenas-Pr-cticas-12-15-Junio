package com.viewnext.business;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import com.viewnext.interfaz.ItfzHttp;

public class HttpImpl implements ItfzHttp {

	@Override
	public HttpResponse<String> solicitar(String url) throws Exception{
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();

		// Crear el cliente
		HttpClient cliente = HttpClient.newHttpClient();

		// El cliente envia la peticion
		HttpResponse<String> respuesta = cliente.send(request, HttpResponse.BodyHandlers.ofString());

		return respuesta;
	}

}
