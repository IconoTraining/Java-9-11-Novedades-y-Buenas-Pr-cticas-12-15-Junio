package com.viewnext;

public class AppMain {

	public static void main(String[] args) {
		
		System.out.println("Esto es una prueba de ejecutar sin compilar");

	}

}
