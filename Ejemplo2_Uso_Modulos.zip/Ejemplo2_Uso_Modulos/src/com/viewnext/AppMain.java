package com.viewnext;

import com.viewnext.models.Direccion;
import com.viewnext.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Empleado empleado1 = new Empleado(1, "Juan", 57_000, 
				new Direccion("Mayor", 5, "Madrid"));
		
		System.out.println(empleado1);

	}

}
