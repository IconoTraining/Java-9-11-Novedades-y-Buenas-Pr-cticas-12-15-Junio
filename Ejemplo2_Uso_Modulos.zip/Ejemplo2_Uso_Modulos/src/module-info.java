// Es mejor poner el nombre del dominio para que sea unico
module com.viewnext.segundomodulo {
	
	requires com.viewnext.primermodulo;
}