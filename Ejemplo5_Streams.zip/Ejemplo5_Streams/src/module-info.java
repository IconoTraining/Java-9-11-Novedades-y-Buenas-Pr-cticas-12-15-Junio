module Ejemplo5_Streams {
}