package com.viewnext;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.viewnext.models.Provincia;
import com.viewnext.utils.Utilidad;

public class OperacionesFinales {

	public static void main(String[] args) {
		
		List<Provincia> provincias = Utilidad.crearLista();
		
		// max
		// Provincia con mayor numero de habitantes
		Provincia maxHabitantes = provincias.stream()
				.max(Comparator.comparing(Provincia::getPoblacion)).get();
		System.out.println(maxHabitantes);
		System.out.println("-------------------------");

		
		// min
		// La menor densidad
		double minDensidad = provincias.stream()
				.mapToDouble(prov -> prov.getDensidadPoblacion())
				.min().getAsDouble();
		System.out.println(minDensidad);
		System.out.println("-------------------------");
		
		
		// average
		double mediaLocalidades = provincias.stream()
				.mapToInt(prov -> prov.getNumLocalidades())
				.average().getAsDouble();
		System.out.println(mediaLocalidades);
		System.out.println("-------------------------");
		
		
		// count
		long numProvinciasPocaDensidad = provincias.stream()
				.filter(prov -> prov.getDensidadPoblacion() < 50)
				.count();
		System.out.println(numProvinciasPocaDensidad);
		System.out.println("-------------------------");
		
		
		// collect
		List<Provincia> espanyol = provincias.stream()
				.filter(prov -> prov.getDialecto().equals("Español"))
				.collect(Collectors.toList());
		espanyol.forEach(System.out::println);
		System.out.println("-------------------------");
		
		
		Map<String, List<Provincia>> grupoDialecto = provincias.stream()
				.collect(Collectors.groupingBy(Provincia::getDialecto));
		grupoDialecto.forEach((k, v) -> {
			System.out.println("Dialecto: " + k);
			v.forEach(System.out::println);
		});
		System.out.println("-------------------------");
		
		
		String dialectos = provincias.stream()
				.map(prov -> prov.getDialecto())
				.distinct()
				.collect(Collectors.joining(" - "));
		System.out.println(dialectos);
		System.out.println("-------------------------");
		
		
		// sum
		int habitantes = provincias.stream()
				.mapToInt(prov -> prov.getPoblacion())
				.sum();
		System.out.println("Total de la poblacion: " + habitantes);
		System.out.println("-------------------------");
		
		
		

	}

}








