package com.viewnext;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;

public class AppMain {

	public static void main(String[] args) throws Exception{
		
		// Ejemplo clasico

//		try {
//			Connection con = DriverManager.getConnection("","","");
//			
//		} catch(Exception ex) {
//			
//		} finally {
//			// La variable con se ha declarado en el bloque try
//			con.close();
//		}
		
		
		
		// Utilizando el try con recursos no se necesita el bloque finally
		// Version 1
		try(Connection con = DriverManager.getConnection("","","")) {
			
			// Cierra la conexion de forma automatica
		} catch(Exception ex) {
			// Cierra la conexion de forma automatica
		} 
		
		
		// Version 2
		Connection con = DriverManager.getConnection("","","");
		try(con) {
			
			// Cierra la conexion de forma automatica
		} catch(Exception ex) {
			// Cierra la conexion de forma automatica
		} 
		
				
		// Lectura de ficheros
		try(FileReader fr = new FileReader("datos.txt");
			BufferedReader br  = new BufferedReader(fr)){
			
			// Cierra todo de forma automatica
		} catch(Exception ex) {
			// Cierra todo de forma automatica
		}
		
	}

}
