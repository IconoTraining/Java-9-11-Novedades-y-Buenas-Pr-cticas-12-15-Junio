module Ejemplo6_Try_with_resources {
	
	requires java.sql;
}