module Ejemplo18_Reactive_Streams {
	
	requires java.base;
}