package com.viewnext.models;

public class Mensaje {
	
	private String texto;
	private int numero;
	
	public Mensaje() {
		// TODO Auto-generated constructor stub
	}

	public Mensaje(String texto, int numero) {
		super();
		this.texto = texto;
		this.numero = numero;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	@Override
	public String toString() {
		return "Mensaje [texto=" + texto + ", numero=" + numero + "]";
	}
	
	

}
