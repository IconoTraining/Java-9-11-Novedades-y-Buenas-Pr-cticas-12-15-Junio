package com.viewnext;

import java.util.concurrent.Flow;
import java.util.concurrent.Flow.Subscription;

import com.viewnext.models.Mensaje;

import java.util.concurrent.SubmissionPublisher;

public class AppMain {
	
	private static class Subscriptor implements Flow.Subscriber<Mensaje>{
		
		private Flow.Subscription subscription;

		@Override
		public void onSubscribe(Subscription subscription) {
			this.subscription = subscription;	
			subscription.request(1);
		}

		@Override
		public void onNext(Mensaje item) {
			System.out.println("Mensaje recibido: " + item);
			subscription.request(1);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		@Override
		public void onError(Throwable error) {
			error.printStackTrace();
		}

		@Override
		public void onComplete() {
			System.out.println("Subscriptor completo");
		}
		
	}
	
	
	private static class Procesador extends SubmissionPublisher<Mensaje> implements Flow.Processor<Mensaje, Mensaje>{

		private Flow.Subscription subscription;
		
		@Override
		public void onSubscribe(Subscription subscription) {
			this.subscription = subscription;
			subscription.request(1);
		}

		@Override
		public void onNext(Mensaje item) {
			// publicar el mensaje
			submit(item);
			System.out.println("Mensaje enviado: " + item);
			subscription.request(1);
		}

		@Override
		public void onError(Throwable error) {
			error.printStackTrace();
		}

		@Override
		public void onComplete() {
			System.out.println("Publicador completo");
			close();
		}
		
	}
	

	public static void main(String[] args) throws InterruptedException {
		// Crear el publicador
		SubmissionPublisher<Mensaje> publicador = new SubmissionPublisher<>();
		
		// Crear el procesador
		Flow.Processor<Mensaje, Mensaje> processor = new Procesador();
		
		// Crear el subscriptor
		Flow.Subscriber<Mensaje> subscriptor = new Subscriptor();
		
		publicador.subscribe(processor);
		processor.subscribe(subscriptor);
		
		for(int i = 1; i<=10; i++) {
			publicador.submit(new Mensaje("Prueba", i));
			Thread.sleep(2000);
		}
		
		publicador.close();

	}

}











