module com.viewnext.mymodulo {
	
	requires java.net.http;
	
}