package com.viewnext.models;

public class Mensaje {
	
	String texto
	int numero

}
