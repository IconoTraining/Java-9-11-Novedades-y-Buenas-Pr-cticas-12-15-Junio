package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;

public class AppMain {

	public static void main(String[] args) {
		
		
		// A traves de un bucle solicitar datos al usuario que vais a guardar en el fichero
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce texto (FIN para terminar): ");
		String texto = sc.nextLine();
		

		Path path = Paths.get("salida.txt");
		try {
			Files.createFile(path);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		while (!"FIN".equals(texto)) {
			
			try {
				Files.writeString(path, texto, StandardOpenOption.APPEND);
				Files.writeString(path, "\n", StandardOpenOption.APPEND);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("Introduce texto (FIN para terminar): ");
			texto = sc.nextLine();
		}
		
		
	

	}

}
