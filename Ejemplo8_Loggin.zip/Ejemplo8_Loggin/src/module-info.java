module com.viewnext.ejemplologin {
	
	requires java.logging;
	
}