module com.viewnext.inferencia {
}