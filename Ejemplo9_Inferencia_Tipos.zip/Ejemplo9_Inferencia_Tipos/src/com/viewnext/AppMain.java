package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;

public class AppMain {
	
	// La inferencia de tipos solo funciona en variables locales
	// var prueba = 200;

	public static void main(String[] args) {
		
		var prueba = 200;
		
		// No se puede aplicar a variables sin inicializar o nulas
		// var noInit;
		// var nula = null;
		
		// Cuidado con los arrays
		// var numeros = {1,2,3,4,5};  // ERROR
		var numeros2 = new int[]{1,2,3,4,5};
		
		// Colecciones
		var lista = new ArrayList<Integer>(Arrays.asList(1,2,3,4));
		var lista2 = new ArrayList<>(Arrays.asList(1,2,3,4));
		var lista3 = new ArrayList<Integer>();
		var lista4 = new ArrayList<>();
		
		
		for(var num = 1; num <= 10; num++) {
			System.out.println(num);
		}
		
		
		var nombres = new String[] {"Juan", "Maria", "Pedro", "Luis", "Sara"};
		for (var item : nombres) {
			System.out.println(item);
		}
		
		// La inferencia de tipos tambien funciona en las variables locales de Lambda
		Operaciones op = (var n1, var n2) ->{
			return(n1 + n2);
		};	
		System.out.println(op.operacion(7, 5));
		
		
		// Tampoco funciona si guardamos el valor de invocar a un metodo void
		//var respuesta = new AppMain().saludo();
		

	}
	
	public void saludo() {
		System.out.println("Hola......");
	}
		

}


interface Operaciones{
	double operacion(double n1, double n2);
}












