package com.viewnext;

import java.util.ServiceLoader;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import com.viewnext.interfaz.ItfzHttp;

public class AppMain {

	public static void main(String[] args) throws Exception {
		ServiceLoader<ItfzHttp> loader = ServiceLoader.load(ItfzHttp.class);
		Iterable<ItfzHttp> iterable = () -> loader.iterator();
		Stream<ItfzHttp> stream = StreamSupport.stream(iterable.spliterator(), false);
		ItfzHttp peticion = stream.findAny().get();
		
		System.out.println(peticion.solicitar("https://api.chucknorris.io/jokes/random").body());

	}

}
