module consumidor {
	
	requires java.net.http;
	requires servicio;
	uses com.viewnext.interfaz.ItfzHttp;
	
}