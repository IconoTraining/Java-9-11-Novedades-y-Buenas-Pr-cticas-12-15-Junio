package com.viewnext;

import java.util.List;
import java.util.stream.Collectors;

public class AppMain {

	public static void main(String[] args) {
		
		// isBlank()
		System.out.println("Hola".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		
		
		// repeat()
		System.out.println("*".repeat(10));
		System.out.println("-".repeat(20));
		System.out.println("Ja".repeat(5));
		
		
		// strip()
		String nombre = " Juan ";
		System.out.println("Hola, soy" + nombre + ".");
		System.out.println("Hola, soy" + nombre.strip() + ".");
		// Quitar el espacio de la derecha
		System.out.println("Hola, soy" + nombre.stripTrailing() + ".");
		// Quitar el espacio de la izquierda
		System.out.println("Hola, soy" + nombre.stripLeading() + ".");
		
		
		// lines()
		String texto = "Hola\nsoy\nAnabel\ny\nesto\nes\nuna\nprueba";
		System.out.println(texto);
		// Coger cada linea y generar una lista donde cada una es un elemento
		System.out.println(texto.lines().collect(Collectors.toList()));
		
		List<String> lista = texto.lines().collect(Collectors.toList());
		for (String linea : lista) {
			System.out.println(linea.toUpperCase());
		}

	}

}
