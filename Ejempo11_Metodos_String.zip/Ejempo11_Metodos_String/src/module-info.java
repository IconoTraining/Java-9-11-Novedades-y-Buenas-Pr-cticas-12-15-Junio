module Ejempo11_Metodos_String {
}