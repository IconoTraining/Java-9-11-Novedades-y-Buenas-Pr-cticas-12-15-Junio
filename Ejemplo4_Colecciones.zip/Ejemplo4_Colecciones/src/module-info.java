module Ejemplo4_Colecciones {
}