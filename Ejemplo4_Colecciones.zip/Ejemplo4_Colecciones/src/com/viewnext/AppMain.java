package com.viewnext;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		List<String> nombres = new ArrayList<String>();
		nombres.add("Juan");
		nombres.add("Maria");
		nombres.add("Pedro");
		// nombres.add(null);   si permite valores nulos
		
		nombres.remove(0);
		System.out.println(nombres);
		
		// Java 9 permite crear listas inmutables
		// Como las tuplas de Python
		List<String> nombres2 = List.of("Juan", "Maria", "Pedro");
		// java.lang.UnsupportedOperationException
		//nombres2.remove(0);
		
		// Tampoco puedo agregar elementos
		//nombres2.add("Pepito");
		System.out.println(nombres2);
		
		// Tanto en List como en Set no permite valores nulos
		//Set<Integer> numeros = Set.of(1,3,5,7,9, null);
		Set<Integer> numeros = Set.of(1,3,5,7,9);
		System.out.println(numeros);
		
		Map<String, Double> alumnos = Map.of("Juan", 7.8, "Maria", 9.2, "Pedro", 5.3);
		System.out.println(alumnos.keySet());
		System.out.println(alumnos.values());
		System.out.println(alumnos.entrySet());
		
		// No podemos modificar valores por ser un mapa inmutable
		// alumnos.put("Pedro", 6.3);
		
		nombres.forEach(name -> System.out.println(name.toUpperCase()));

	}

}
