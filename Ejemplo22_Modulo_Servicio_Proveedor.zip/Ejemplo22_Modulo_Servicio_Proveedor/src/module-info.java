module proveedor {
	
	requires service;
	provides com.viewnext.interfaz.ItfzSaludo with com.viewnext.impl.Saludo;
	
}