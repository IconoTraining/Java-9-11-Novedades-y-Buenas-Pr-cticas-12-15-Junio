package com.viewnext;

import java.util.Set;

public class AppMain {
	
	
	// java /Users/anaisabelvegascaceres/Desktop/Novedades9-11-ViewNext-12-Junio/Ejemplo10_Ejecuccion_Sin_Compilar/src/com/viewnext/AppMain.java
	// Solo me funciona si tengo SOLO la clase principal
	
	public static void main(String[] args) {
		
		// Crear un set inmutable con 5 productos
		Set<Producto> productos = Set.of(
				new Producto(1, "Pantalla", 149.95),
				new Producto(2, "Raton", 29.50),
				new Producto(3, "Impresora", 89),
				new Producto(4, "Teclado", 45),
				new Producto(5, "Scanner", 260));
		
		for (Producto producto : productos) {
			System.out.println(producto);
		}

	}

}
