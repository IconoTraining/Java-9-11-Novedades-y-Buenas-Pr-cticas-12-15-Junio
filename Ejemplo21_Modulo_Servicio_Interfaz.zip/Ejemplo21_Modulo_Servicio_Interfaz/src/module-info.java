module service {
	
	exports com.viewnext.interfaz;
}