module Ejemplo12_Variables_Locales_Lambda {
}