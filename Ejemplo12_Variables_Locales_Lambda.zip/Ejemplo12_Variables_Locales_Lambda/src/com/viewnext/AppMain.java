package com.viewnext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.viewnext.models.Alumno;

public class AppMain {

	public static void main(String[] args) {
		
		// Alumnos esten ordenados por el nombre 
		// La inferencia de tipos funciona en las variables locales de Lambda
		Comparator<Alumno> porNombre = (var a1, var a2) -> 
			a1.getNombre().compareTo(a2.getNombre());
		
		Set<Alumno> alumnos = new TreeSet<>(porNombre);
		alumnos.add(new Alumno(1, "Juan", "Perez", 'H', 7.5, false));
		alumnos.add(new Alumno(2, "Maria", "Sanchez", 'M', 4.2, true));
		alumnos.add(new Alumno(3, "Pedro", "Gonzalez", 'H', 9.5, false));
		alumnos.add(new Alumno(4, "Luis", "Rodriguez", 'H', 8.3, false));
		alumnos.add(new Alumno(5, "Sara", "Garcia", 'M', 10, true));
		
		alumnos.forEach(System.out::println);
		System.out.println("-".repeat(30));
		
		
		// Generar una lista con los elementos del set
		List<Alumno> lista = new ArrayList<Alumno>(alumnos);
		
		
		// Ordenar la lista por nota
		lista.sort( (var a1, var a2) -> (int) (a1.getNota() - a2.getNota()) ) ;
		
		// Si utilizo inferncia de tipos ha de ser en todos los argumentos del Lambda
		// lista.sort( (Alumno a1, var a2) -> (int) (a1.getNota() - a2.getNota()) ) ;
		lista.forEach(System.out::println);
		System.out.println("-".repeat(30));
		
		
		// Ordenar la lista por numAlumno descendente
		lista.sort( (var a1, var a2) -> (int) (a2.getNumAlumno() - a1.getNumAlumno()) ) ;
		lista.forEach(System.out::println);
		System.out.println("-".repeat(30));

	}

}
